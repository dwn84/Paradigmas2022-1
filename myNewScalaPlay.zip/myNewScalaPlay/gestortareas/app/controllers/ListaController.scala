package controllers

import javax.inject._
import play.api._
import play.api.mvc._

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class ListaController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {

  private val ml = List("asdf","jkl;","qwer")

  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.miLista(ml))
  }
  def addNewItem(n: String) = Action { implicit request: Request[AnyContent] =>
    val b = n +: ml
    Ok(views.html.miLista(b))
  }


}
