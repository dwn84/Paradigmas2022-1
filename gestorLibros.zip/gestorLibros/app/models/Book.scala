package models
import scala.collection.mutable._

object Book {

  var books = Set[Book](new Book(1, "C++", 20, "ABC"))

  books += new Book(2, "JAVA", 20, "XYZ")
  books += new Book(3, "SCALA", 20, "MNB")
  def allBooks(): Set[Book] = {
    books
  }

  def findById(id: Int): Book = {
    for (book <- books) {
      if (id == book.id) return book
    }
    null
  }

  def add(book: Book): Unit = {
    books+=book
  }

  def remove(id: Int): Unit ={
    books = books.filter(_.id!=id)
  }



}

case class Book(id: Int, title: String, price: Int, author: String) {

}



