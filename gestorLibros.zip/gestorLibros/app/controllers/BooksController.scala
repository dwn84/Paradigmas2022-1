package controllers
/*https://egimaben.github.io/2019/07/23/play-framework-primer-forms*/
import models.Book
import play.api.data.Form
import play.api.data.Forms._
import scala.collection.mutable.ListBuffer

import javax.inject._
import play.api._
import play.api.i18n.I18nSupport.RequestWithMessagesApi
import play.api.i18n.Messages
import play.api.mvc._

import scala.collection.mutable.Set

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class BooksController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {

  val bookForm = Form(
    mapping(
      "id" -> number,
      "title" -> text,
      "price" -> number,
      "author" -> text,
    )(Book.apply)(Book.unapply)
  )


  def index() = Action { implicit request: Request[AnyContent] =>
    var books = Book.allBooks()
    Ok(views.html.books(books))
  }
  def create() = Action { implicit request: Request[AnyContent] =>
    val messages: Messages =request.messages
    Ok(views.html.newBook(bookForm)(messages))
  }
  def save() = Action { implicit request: Request[AnyContent] =>

    bookForm.bindFromRequest.fold(
      formWithErrors =>
        BadRequest(views.html.index()),
      bookData => {
        Book.add(new Book(bookData.id,bookData.title,bookData.price,bookData.author))
        Redirect(routes.BooksController.index)
      }
    )
  }
  def edit(id: Int) = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }
  def update() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }
  def delete(id: Int) = Action { implicit request: Request[AnyContent] =>
    Book.remove(id)
    Redirect(routes.BooksController.index)
  }
  def show(id: Int) = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }
}


